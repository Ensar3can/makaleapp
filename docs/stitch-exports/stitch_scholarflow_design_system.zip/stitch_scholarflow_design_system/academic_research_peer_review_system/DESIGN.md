---
name: Academic Research & Peer Review System
colors:
  surface: '#fcf8fa'
  surface-dim: '#dcd9db'
  surface-bright: '#fcf8fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#eae7e9'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#45464d'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#271901'
  on-tertiary-container: '#98805d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#fcdeb5'
  tertiary-fixed-dim: '#dec29a'
  on-tertiary-fixed: '#271901'
  on-tertiary-fixed-variant: '#574425'
  background: '#fcf8fa'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  display-title:
    fontFamily: ebGaramond
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  article-headline:
    fontFamily: ebGaramond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  body-main:
    fontFamily: hankenGrotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  ui-label-bold:
    fontFamily: hankenGrotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  caption:
    fontFamily: hankenGrotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: '0'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1140px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-gap: 64px
---

## Brand & Style
This design system bridges the gap between the intellectual rigor of a high-end research journal and the streamlined efficiency of modern productivity software. The brand personality is rooted in **Reliability, Transparency, and Precision**. It avoids the clutter often found in academic repositories, opting instead for a "Premium Editorial" experience.

The visual style is characterized by a "Modern Institutional" aesthetic:
- **Intellectual Clarity:** High-contrast serif headlines provide an authoritative, editorial voice.
- **Data-Driven Transparency:** Information is presented through a structured grid, ensuring that peer review data and metrics are easily digestible.
- **Quiet Sophistication:** The interface uses generous whitespace and a "less is more" approach to information density, ensuring that the research remains the focal point.

## Colors
The color palette is anchored by the seed color, a deep slate-navy that conveys institutional trust and stability. 

- **Primary & Neutral:** The interface relies heavily on the interaction between the deep navy text and the off-white background. This high-contrast pairing ensures excellent legibility for long-form reading.
- **Semantic Accents:** Colors are used exclusively for data signaling. Emerald Green denotes high-quality scores and "Published" states. Amber is reserved for warnings or "In Review" status. Brick Red is used with extreme restraint, reserved only for critical errors or rejections.
- **Grayscale:** A sophisticated range of Slate grays manages the UI hierarchy without competing with the editorial content.

## Typography
The typography system employs a dual-font strategy to balance tradition with modernity.

- **Editorial Layer:** `ebGaramond` is used for article titles, section headers, and pull quotes. This serif choice evokes the heritage of printed journals and encourages deep focus.
- **Functional Layer:** `hankenGrotesk` is the primary workhorse for the UI. Its sharp, contemporary letterforms ensure that navigation, metadata, and technical data are clear and professional.
- **Hierarchy:** We utilize a tight, structured scale. Large serif headlines are paired with smaller, clean sans-serif body text to create a high-contrast, "journalistic" layout.

## Layout & Spacing
The layout philosophy is defined by a **Fixed Grid** with a generous, structured rhythm.

- **The Reading Column:** For article content, use a centered, narrow column (max 720px) to maximize readability.
- **The Dashboard Grid:** A 12-column grid system with wide gutters (24px) allows for clear separation of data widgets and paper lists.
- **Information Density:** Deliberately low. Every screen should focus on no more than two primary actions. Avoid "dashboard fatigue" by using ample padding within cards and around page headers.
- **Breakpoints:**
  - Mobile: Single column, 16px side margins.
  - Tablet: 8-column grid, 32px margins.
  - Desktop: 12-column grid, max 1140px container.

## Elevation & Depth
This design system uses **Tonal Layering** and **Subtle Outlines** rather than heavy shadows to create depth.

- **Surface Tiers:** The background uses a soft Slate (`#F8FAFC`). Primary containers (cards, paper previews) use a pure white surface.
- **Refined Borders:** Elements are defined by 1px solid borders in a light gray (`#E2E8F0`). 
- **The Hover Lift:** To signal interactivity, cards use a very subtle, diffused ambient shadow (8% opacity) that slightly intensifies on hover, paired with a 2px upward translation.
- **Minimalism:** Shadows should be almost imperceptible, serving only to separate the primary content from the background canvas.

## Shapes
In line with the "Soft" (`1`) roundedness directive:
- **Base Components:** Buttons, input fields, and status badges use a `0.25rem` (4px) corner radius. This maintains a professional, slightly technical edge.
- **Containers:** Large cards and editorial sections use `0.75rem` (12px) to provide a modern, approachable feel to the layout.
- **Interactive Elements:** Checkboxes and specialized UI icons maintain sharp or minimally rounded corners to reinforce the precision of the data.

## Components

### Score Indicators
A 0-100 scale visualized as a **circular gauge** or a large-format badge. 
- **High (70-100):** Emerald Green.
- **Mid (40-69):** Amber.
- **Low (0-39):** Brick Red.
Use `hankenGrotesk` Bold for the numerical value to ensure it is the primary focal point of the review card.

### AI Writing Risk
A neutral, horizontal 5-level scale. Each level is represented by a small colored dot and a text label:
- **Very Low / Low:** Subtle Slate or Teal.
- **Uncertain:** Light Gray.
- **High / Very High:** Muted Amber.
The tone must remain objective and non-alarmist.

### Status Badges
Small, semi-capsule shapes with a `rounded-md` radius. Use neutral backgrounds with high-contrast text:
- **Default:** Light Slate background with Deep Navy text.
- **Success (Published):** Light Emerald background with Dark Green text.
- **Warning (Under Review):** Light Amber background with Dark Orange text.

### Buttons
- **Primary:** Solid Deep Navy (`#0F172A`) with white text. High-density, professional.
- **Secondary:** 1px Outline in Deep Navy with no fill.
- **Danger:** Brick Red text with a subtle 1px Brick Red outline; only for "Retract" or "Delete" actions.

### Cards
White surfaces with a `12px` corner radius. Include a 1px border (`#E2E8F0`). On hover, the border color should darken slightly to the primary navy, and the card should "lift" via a subtle shadow.

### Navigation
A fixed top header with a pure white background and a 1px bottom stroke. Navigation items should use `ui-label-bold` with 48px horizontal spacing between links.